import products from "./products";
import categories from "./categories";

export default {
  products,
  categories
};
