import React from "react";
import { connect } from "react-redux";

import Product from "../components/Product";
import Category from "../components/Caregory";

class ProductsPage extends React.Component {
  componentDidMount() {
    this.props.loadProducts();
    this.props.loadCategories();
  }
  // componentDidMount() {
  //   this.loadData(this.props);
  // }

  // // https://github.com/ReactTraining/react-router/issues/4407
  // componentWillReceiveProps(nextProps) {
  //   if (nextProps.match.url !== this.props.match.url) {
  //     this.loadData(nextProps);
  //   }
  // }

  // loadData(props) {
  //   let productsParams = {};
  //   if (props.match.path === "/categories/:id") {
  //     productsParams = { filter: { categoryId: props.match.params.id } };
  //   }

  //   props.loadProducts(productsParams);
  //   props.loadCategories();
  // }

  render() {
    return (
      <div>
        <h1>Categories</h1>
        {this.props.categories.map(category => (
          <Category key={category.id} category={category} />
        ))}

        <h1>Products Page {this.props.products.length}</h1>
        {this.props.products.map(product => (
          <Product key={product.id} product={product} />
        ))}
      </div>
    );
  }
}

const mapState = ({ products, categories }) => ({
  products: products.list,
  categories: categories.list
});

const mapDispatch = ({ products, categories }) => ({
  loadProducts: products.loadAll,
  loadCategories: categories.loadAll
});

export default connect(
  mapState,
  mapDispatch
)(ProductsPage);
